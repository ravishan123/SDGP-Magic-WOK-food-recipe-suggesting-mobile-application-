from django.apps import AppConfig


class IndexpageConfig(AppConfig):
    name = 'indexpage'
