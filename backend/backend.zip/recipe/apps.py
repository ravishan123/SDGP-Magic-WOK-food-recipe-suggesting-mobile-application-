from django.apps import AppConfig


class RecipeConfig(AppConfig):
    name = 'recipe'
